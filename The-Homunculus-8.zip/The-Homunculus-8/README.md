# The Homunculus

<p align="center">
  <a href="//discord.com/invite/6bHRzQX3Qz"><img src="https://img.shields.io/discord/814173270919479317?logo=discord"></a>
  <a href="//github.com/raventhecat333/The-Homunculus/commits/main"><img src="https://img.shields.io/github/last-commit/raventhecat333/The-Homunculus"></a>
  <a href="//github.com/raventhecat333/The-Homunculus/releases"><img src="https://img.shields.io/github/downloads/raventhecat333/The-Homunculus/total"></a>
  <a href="//github.com/raventhecat333/The-Homunculus/blob/main/LICENSE.MD"><img src="https://img.shields.io/github/license/raventhecat333/The-Homunculus?style=plastic"></a>
  <a href="//github.com/raventhecat333/The-Homunculus"><img src="https://img.shields.io/github/languages/code-size/raventhecat333/The-Homunculus"></a>
  <a href="//github.com/raventhecat333/The-Homunculus/issues"><img src="https://img.shields.io/github/issues-raw/raventhecat333/The-Homunculus"></a>
</p>
* Clone/Download the repository
    * To clone it and get the updates you can use the command
      `git clone`
* Create a discord bot [here](https://discord.com/developers/applications)
* Get your bot token
* Invite your bot on servers using the following invite:
  https://discordapp.com/oauth2/authorize?&client_id=YOUR_APPLICATION_ID_HERE&scope=bot&permissions=8 (
  Replace `YOUR_APPLICATION_ID_HERE` with the application ID)

## How to set up

To set up the bot there is a [config.json](config.json) file where you can put the
needed things to edit.

Here is an explanation of what everything is:

| Variable                  | What it is                                                            |
| ------------------------- | ----------------------------------------------------------------------|
| YOUR_BOT_PREFIX_HERE      | The prefix(es) of your bot                                            |
| YOUR_BOT_TOKEN_HERE       | The token of your bot                                                 |
| YOUR_APPLICATION_ID_HERE  | The application ID of your bot                                        |
| OWNERS                    | The user ID of all the bot owners                                     |

In the [blacklist](blacklist.json) file you now can add IDs (as integers) in the `ids` list.

## How to start

To start the bot you simply need to launch, either your terminal (Linux, Mac & Windows), or your Command Prompt (
Windows)
.

Before running the bot you will need to install all the requirements with this command:

```
pip3 install -r requirements.txt
```

If you have multiple versions of python installed (2.x and 3.x) then you will need to use only pyhon3

```
python3 bot.py
```

## Issues or Questions
* Join my discord server [here](https://bit.ly/EnvysDomain)

## Built With

* [Python 3.7](https://www.python.org/)

## License

This project is licensed under the GPL 3.0 - see the [LICENSE](LICENSE) file for details
s
